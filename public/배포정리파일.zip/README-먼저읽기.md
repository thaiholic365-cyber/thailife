# 🚀 타이라이프 배포 — 바로 시작

이 폴더를 통째로 GitHub에 올리면 됩니다. Supabase 키는 이미 들어있습니다.

## 폴더 구조
```
deploy/
├── public/
│   ├── index.html       지도
│   ├── community.html   커뮤니티
│   ├── admin.html       관리자
│   ├── config.js        ✅ Supabase 키 입력완료
│   └── tl-api.js        데이터 레이어
├── supabase/schema.sql  DB 설계도
├── vercel.json          ✅ 설정 완료
└── 배포방법.md          상세 가이드
```

## 3단계로 끝

### 1️⃣ Supabase 준비 (아직 안 했다면)
- SQL Editor에서 `supabase/schema.sql` 전체 실행
- Storage에 `images` 버킷 생성 (Public)
- **Authentication → Providers → Email → Confirm email 끄기** ⚠️ 필수

### 2️⃣ GitHub 업로드
- 이 `deploy` 폴더 **안의 내용**을 저장소에 올리기
  (public 폴더, supabase 폴더, vercel.json이 저장소 최상위에 오도록)

### 3️⃣ Vercel 배포
- Import → **Output Directory는 vercel.json이 자동 처리** → Deploy
- Settings → Deployment Protection → **Disabled** (손님 접속용)

## 배포 후: 관리자 만들기
1. 커뮤니티에서 회원가입 (핸드폰번호로)
2. Supabase SQL Editor에서 실행 (본인 번호로 수정):
   ```sql
   insert into admins(user_id)
   select id from auth.users
   where email = '01012345678@tl.local';
   ```
   (010-1234-5678 → 01012345678@tl.local 형식)
3. `/admin`에서 핸드폰번호+비밀번호로 로그인

## 문제 생기면
화면에 나오는 메시지를 확인하세요. 이제 "TL is not defined" 대신
구체적인 원인(SDK 로드 실패 / config 오류 등)이 표시됩니다.
